package edu.eci.arsw.parcial2ARSW;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Parcial2ArswApplication {

	public static void main(String[] args) {
		SpringApplication.run(Parcial2ArswApplication.class, args);
	}

}
