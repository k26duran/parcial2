package edu.eci.arsw.parcial2ARSW;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class Parcial2ArswApplicationTests {

	@Test
	public void contextLoads() {
	}

}
